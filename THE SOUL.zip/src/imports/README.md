
  # THE SOUL

  This is a code bundle for THE SOUL. The original project is available at https://www.figma.com/design/tGjvgHgiQIDuzBai5YX3sd/THE-SOUL.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  