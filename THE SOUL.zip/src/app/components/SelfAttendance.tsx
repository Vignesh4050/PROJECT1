import { useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';

interface SelfAttendanceProps {
  onClose: () => void;
}

const motivationalQuotes = [
  "The only way to do great work is to love what you do. - Steve Jobs",
  "Believe you can and you're halfway there. - Theodore Roosevelt",
  "Your time is limited, don't waste it living someone else's life. - Steve Jobs",
  "Success is not final, failure is not fatal: it is the courage to continue that counts. - Winston Churchill",
  "The future belongs to those who believe in the beauty of their dreams. - Eleanor Roosevelt",
  "It does not matter how slowly you go as long as you do not stop. - Confucius",
  "Everything you've ever wanted is on the other side of fear. - George Addair",
  "Believe in yourself. You are braver than you think, more talented than you know, and capable of more than you imagine. - Roy T. Bennett",
  "Start where you are. Use what you have. Do what you can. - Arthur Ashe",
  "Don't watch the clock; do what it does. Keep going. - Sam Levenson",
];

export default function SelfAttendance({ onClose }: SelfAttendanceProps) {
  const [currentDate, setCurrentDate] = useState(new Date(2026, 2, 1)); // March 2026
  const [attendance, setAttendance] = useState<Record<string, 0 | 1 | 2>>({}); // 0: none, 1: present (green), 2: absent (red)
  const [quote] = useState(() => motivationalQuotes[Math.floor(Math.random() * motivationalQuotes.length)]);

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    return { firstDay, daysInMonth };
  };

  const { firstDay, daysInMonth } = getDaysInMonth(currentDate);

  const handleDateClick = (day: number) => {
    const key = `${currentDate.getFullYear()}-${currentDate.getMonth()}-${day}`;
    const current = attendance[key] || 0;
    const next = current === 2 ? 0 : current + 1;
    setAttendance({ ...attendance, [key]: next as 0 | 1 | 2 });
  };

  const getDateStatus = (day: number) => {
    const key = `${currentDate.getFullYear()}-${currentDate.getMonth()}-${day}`;
    return attendance[key] || 0;
  };

  const prevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  };

  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  };

  const monthNames = ["January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"];

  const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

  return (
    <div className="p-8">
      {/* Dialog Header for Accessibility */}
      <DialogHeader>
        <DialogTitle>Self Attendance - Daily Check-in</DialogTitle>
        <DialogDescription>
          Track your daily commitment and mark your attendance
        </DialogDescription>
      </DialogHeader>

      {/* Motivational Quote */}
      <div className="mb-8 text-center">
        <p className="text-lg text-gray-600 italic">&ldquo;{quote}&rdquo;</p>
      </div>

      {/* Header */}
      <div className="mb-6">
        <h2 className="text-3xl text-gray-800 mb-2">Self Attendance</h2>
        <p className="text-sm text-gray-500">
          Track your daily commitment • Click once: Present (Green) • Click twice: Absent (Red)
        </p>
      </div>

      {/* Month Navigation */}
      <div className="flex items-center justify-between mb-8">
        <button
          onClick={prevMonth}
          className="p-2 hover:bg-gray-100 rounded-full transition-colors"
        >
          <ChevronLeft className="w-5 h-5 text-gray-600" />
        </button>
        <h3 className="text-xl text-gray-700">
          {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
        </h3>
        <button
          onClick={nextMonth}
          className="p-2 hover:bg-gray-100 rounded-full transition-colors"
        >
          <ChevronRight className="w-5 h-5 text-gray-600" />
        </button>
      </div>

      {/* Calendar */}
      <div className="mb-8">
        {/* Day headers */}
        <div className="grid grid-cols-7 gap-2 mb-4">
          {dayNames.map((day) => (
            <div key={day} className="text-center text-sm text-gray-400 py-2">
              {day}
            </div>
          ))}
        </div>

        {/* Calendar grid */}
        <div className="grid grid-cols-7 gap-2">
          {/* Empty cells for days before month starts */}
          {Array.from({ length: firstDay }).map((_, index) => (
            <div key={`empty-${index}`} className="aspect-square" />
          ))}

          {/* Days of the month */}
          {Array.from({ length: daysInMonth }).map((_, index) => {
            const day = index + 1;
            const status = getDateStatus(day);
            const today = day === 21; // March 21 as shown in the image
            
            return (
              <button
                key={day}
                onClick={() => handleDateClick(day)}
                className={`
                  aspect-square rounded-xl flex items-center justify-center text-sm
                  transition-all hover:scale-105
                  ${status === 0 ? 'bg-gray-50 text-gray-400 hover:bg-gray-100' : ''}
                  ${status === 1 ? 'bg-green-100 text-green-700 border-2 border-green-400' : ''}
                  ${status === 2 ? 'bg-red-100 text-red-700 border-2 border-red-400' : ''}
                  ${today && status === 0 ? 'border-2 border-gray-800' : ''}
                `}
              >
                {day}
              </button>
            );
          })}
        </div>
      </div>

      {/* Legend */}
      <div className="flex items-center justify-center gap-8 mb-6">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-green-100 border-2 border-green-400" />
          <span className="text-sm text-gray-600">Present</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-red-100 border-2 border-red-400" />
          <span className="text-sm text-gray-600">Absent</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gray-50" />
          <span className="text-sm text-gray-600">Unmarked</span>
        </div>
      </div>
    </div>
  );
}