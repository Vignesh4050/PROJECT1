import { useState } from "react";
import { ArrowLeft, Sparkles } from "lucide-react";
import { useNavigate } from "react-router";
import { motion } from "motion/react";
import spiritualBg from "figma:asset/4bbff9a646b2459903edf40f8a17074bccd62db5.png";

const dailyIntentions = [
  "Today, I choose connection over perfection, compassion over judgment, and love as my compass.",
  "I embrace stillness and allow peace to flow through every moment of my day.",
  "Today, I honor my inner voice and trust the wisdom that resides within me.",
  "I release what no longer serves me and welcome abundance in all its forms.",
  "Today, I am present, grounded, and deeply connected to my authentic self.",
];

export default function SpiritualPage() {
  const navigate = useNavigate();
  const [intention] = useState(
    dailyIntentions[
      Math.floor(Math.random() * dailyIntentions.length)
    ],
  );

  const practices = [
    {
      title: "Mindful Moments",
      desc: "Take 3 deep breaths before checking your phone",
    },
    {
      title: "Digital Detox",
      desc: "Create technology-free zones in your day",
    },
    {
      title: "Nature Connection",
      desc: "Spend 10 minutes daily in nature",
    },
    {
      title: "Gratitude Practice",
      desc: "List 3 things you are grateful for each morning",
    },
  ];

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img
          src={spiritualBg}
          alt="Spiritual nature themed background"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-blue-900/30 via-slate-800/20 to-teal-900/30" />
      </div>

      {/* Back button */}
      <motion.button
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        onClick={() => navigate("/")}
        className="fixed top-6 left-6 flex items-center gap-2 text-gray-600 hover:text-gray-800 transition-colors bg-white/60 backdrop-blur-sm px-4 py-2 rounded-full border border-white/50 shadow-lg z-50"
      >
        <ArrowLeft className="w-4 h-4" />
        <span className="text-sm">Back</span>
      </motion.button>

      {/* Main content */}
      <div className="relative z-10 min-h-screen flex items-center justify-center p-6 pt-20">
        <div className="w-full max-w-5xl">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: -30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-12"
          >
            <h1 className="text-5xl font-bold mb-4">
              <span className="bg-gradient-to-r from-blue-500 to-blue-700 bg-clip-text text-transparent">
                Spiritual Connection
              </span>
            </h1>
            <p className="text-black-800">
              Embrace inner peace and purpose
            </p>
          </motion.div>

          {/* Daily Intention Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.8 }}
            className="bg-white/60 backdrop-blur-xl rounded-3xl p-10 border border-white/50 shadow-2xl mb-8"
          >
            <p className="text-black-400 text-xs uppercase tracking-widest text-center mb-6">
              Your Daily Intention
            </p>
            <p
              className="text-2xl text-gray-700 italic text-center leading-relaxed"
              style={{ fontFamily: "Georgia, serif" }}
            >
              "{intention}"
            </p>
          </motion.div>

          {/* Spiritual Practices */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.8 }}
            className="bg-white/60 backdrop-blur-xl rounded-3xl p-8 border border-white/50 shadow-2xl"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-blue-400 rounded-2xl flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-2xl font-semibold text-gray-800">
                  Spiritual Practices
                </h2>
                <p className="text-sm text-gray-500">
                  Daily rituals for inner peace
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {practices.map((practice, index) => (
                <motion.div
                  key={practice.title}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.5 + index * 0.05 }}
                  className="bg-white/80 backdrop-blur-sm rounded-2xl p-5 border border-gray-100 hover:shadow-lg transition-all"
                >
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-400 to-blue-400 flex items-center justify-center flex-shrink-0">
                      <span className="text-xs text-white font-medium">
                        {index + 1}
                      </span>
                    </div>
                    <div>
                      <h4 className="text-base font-semibold text-gray-800 mb-1">
                        {practice.title}
                      </h4>
                      <p className="text-sm text-gray-600">
                        {practice.desc}
                      </p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}