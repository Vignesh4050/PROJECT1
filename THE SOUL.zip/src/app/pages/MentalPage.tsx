import {
  ArrowLeft,
  Briefcase,
  Heart,
  DollarSign,
  Activity,
} from "lucide-react";
import { useNavigate } from "react-router";
import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";

export default function MentalPage() {
  const navigate = useNavigate();
  const [selectedArea, setSelectedArea] = useState<
    string | null
  >(null);

  const lifeAreas = [
    {
      id: "career",
      title: "Career",
      icon: Briefcase,
      gradient: "from-blue-400 to-cyan-400",
      description: "Professional growth and fulfillment",
      questions: [
        "What are my career goals for this year?",
        "Am I growing in my current role?",
        "What skills do I want to develop?",
        "How satisfied am I with my work-life balance?",
      ],
    },
    {
      id: "health",
      title: "Health",
      icon: Activity,
      gradient: "from-green-400 to-emerald-400",
      description: "Physical and mental well-being",
      questions: [
        "How is my physical health today?",
        "Am I maintaining good sleep habits?",
        "What is my exercise routine?",
        "How do I manage stress effectively?",
      ],
    },
    {
      id: "relationship",
      title: "Relationships",
      icon: Heart,
      gradient: "from-pink-400 to-rose-400",
      description: "Connections with loved ones",
      questions: [
        "How are my relationships with family?",
        "Am I nurturing my friendships?",
        "Do I communicate effectively?",
        "Am I investing time in meaningful connections?",
      ],
    },
    {
      id: "money",
      title: "Money",
      icon: DollarSign,
      gradient: "from-amber-400 to-orange-400",
      description: "Financial stability and planning",
      questions: [
        "Am I managing my finances well?",
        "What are my financial goals?",
        "Am I saving for the future?",
        "How can I improve my financial literacy?",
      ],
    },
  ];

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1765438858380-7cd73d0dca60?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZW50YWwlMjBjbGFyaXR5JTIwbWVkaXRhdGlvbiUyMGZvY3VzJTIwemVufGVufDF8fHx8MTc3NDY3OTk1MXww&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Mental clarity themed background"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-blue-900/60 via-cyan-800/50 to-blue-900/60 backdrop-blur-sm" />
      </div>

      {/* Back button */}
      <motion.button
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        onClick={() => navigate("/")}
        className="fixed top-6 left-6 flex items-center gap-2 text-gray-600 hover:text-gray-800 transition-colors bg-white/60 backdrop-blur-sm px-4 py-2 rounded-full border border-white/50 shadow-lg z-50"
      >
        <ArrowLeft className="w-4 h-4" />
        <span className="text-sm">Back</span>
      </motion.button>

      {/* Main content */}
      <div className="relative z-10 min-h-screen flex items-center justify-center p-6 pt-20">
        <div className="w-full max-w-6xl">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: -30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-12"
          >
            <h1 className="text-5xl font-bold mb-4">
              <span className="bg-gradient-to-r from-blue-500 to-cyan-500 bg-clip-text text-transparent">
                Mental Balance
              </span>
            </h1>
            <p className="text-gray-600">
              Four pillars for a balanced life
            </p>
          </motion.div>

          {/* Life Areas Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {lifeAreas.map((area, index) => {
              const Icon = area.icon;
              const isSelected = selectedArea === area.id;

              return (
                <motion.div
                  key={area.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className={`bg-white/60 backdrop-blur-xl rounded-3xl border border-white/50 shadow-xl overflow-hidden transition-all ${
                    isSelected ? "md:col-span-2" : ""
                  }`}
                >
                  {/* Card Header - Clickable */}
                  <button
                    onClick={() =>
                      setSelectedArea(
                        isSelected ? null : area.id,
                      )
                    }
                    className="w-full p-8 text-left hover:bg-white/20 transition-all"
                  >
                    <div className="flex items-center gap-4">
                      <div
                        className={`w-14 h-14 bg-gradient-to-br ${area.gradient} rounded-2xl flex items-center justify-center shadow-lg`}
                      >
                        <Icon
                          className="w-7 h-7 text-white"
                          strokeWidth={2}
                        />
                      </div>
                      <div className="flex-1">
                        <h2 className="text-2xl font-semibold text-gray-800 mb-1">
                          {area.title}
                        </h2>
                        <p className="text-sm text-gray-600">
                          {area.description}
                        </p>
                      </div>
                      <motion.div
                        animate={{
                          rotate: isSelected ? 180 : 0,
                        }}
                        transition={{ duration: 0.3 }}
                        className="text-gray-400"
                      >
                        <svg
                          className="w-6 h-6"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M19 9l-7 7-7-7"
                          />
                        </svg>
                      </motion.div>
                    </div>
                  </button>

                  {/* Expanded Content */}
                  <AnimatePresence>
                    {isSelected && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.3 }}
                        className="overflow-hidden"
                      >
                        <div className="px-8 pb-8 pt-4 border-t border-white/30">
                          <h3 className="text-lg font-semibold text-gray-700 mb-4">
                            Reflection Questions
                          </h3>
                          <div className="space-y-3">
                            {area.questions.map(
                              (question, qIndex) => (
                                <motion.div
                                  key={qIndex}
                                  initial={{
                                    opacity: 0,
                                    x: -20,
                                  }}
                                  animate={{ opacity: 1, x: 0 }}
                                  transition={{
                                    delay: qIndex * 0.1,
                                  }}
                                  className="bg-white/60 backdrop-blur-sm rounded-2xl p-4 border border-gray-100"
                                >
                                  <div className="flex items-start gap-3">
                                    <div
                                      className={`w-6 h-6 bg-gradient-to-br ${area.gradient} rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5`}
                                    >
                                      <span className="text-xs text-white font-medium">
                                        {qIndex + 1}
                                      </span>
                                    </div>
                                    <div className="flex-1">
                                      <p className="text-gray-700 text-sm font-medium mb-2">
                                        {question}
                                      </p>
                                      <textarea
                                        placeholder="Write your thoughts..."
                                        className="w-full bg-gray-50/50 rounded-xl px-3 py-2 text-sm text-gray-700 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-blue-200 transition-all resize-none"
                                        rows={2}
                                      />
                                    </div>
                                  </div>
                                </motion.div>
                              ),
                            )}
                          </div>

                          <motion.button
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            transition={{ delay: 0.4 }}
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                            className={`mt-6 w-full py-4 bg-gradient-to-r ${area.gradient} text-white rounded-2xl font-medium shadow-lg hover:shadow-xl transition-all`}
                          >
                            Save Reflections
                          </motion.button>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              );
            })}
          </div>

          {/* Bottom Info */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
            className="text-center text-gray-500 text-sm mt-8"
          >
            CLICK ON ANY OF THIS AREAS OF LIFE AND QUESTION YOUR
            FUTURE SELF!
          </motion.p>
        </div>
      </div>
    </div>
  );
}