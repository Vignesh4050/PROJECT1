import { ArrowLeft, MessageCircle, Trash2 } from "lucide-react";
import { useNavigate } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import { useState } from "react";
import psychologicalBg from "figma:asset/33eb7a9a596dd064e1e6e575a7b216066b6759e3.png";

export default function PsychologicalPage() {
  const navigate = useNavigate();
  const [entries, setEntries] = useState<{
    [key: string]: string;
  }>({});
  const [showSuccessMessage, setShowSuccessMessage] =
    useState(false);

  const emotions = [
    {
      name: "Anger",
      emoji: "😡",
      color: "from-violet-400 to-rose-400",
    },
    {
      name: "Fear",
      emoji: "😨",
      color: "from-violet-400 to-rose-400",
    },
    {
      name: "Sadness",
      emoji: "😢",
      color: "from-violet-400 to-rose-400",
    },
    {
      name: "Anxiety",
      emoji: "😰",
      color: "from-violet-400 to-rose-400",
    },
    {
      name: "Guilt",
      emoji: "😔",
      color: "from-violet-400 to-rose-400",
    },
    {
      name: "Jealousy",
      emoji: "😒",
      color: "from-violet-400 to-rose-400",
    },
    {
      name: "Shame",
      emoji: "😳",
      color: "from-violet-400 to-rose-400",
    },
    {
      name: "Confusion",
      emoji: "😕",
      color: "from-violet-400 to-rose-400",
    },
  ];

  const handleEntryChange = (
    emotionName: string,
    value: string,
  ) => {
    setEntries((prev) => ({
      ...prev,
      [emotionName]: value,
    }));
  };

  const handleDumpThoughts = () => {
    // Clear all entries
    setEntries({});

    // Show success message
    setShowSuccessMessage(true);

    // Hide success message after 4 seconds
    setTimeout(() => {
      setShowSuccessMessage(false);
    }, 4000);
  };

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img
          src={psychologicalBg}
          alt="Psychology themed background"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-gray-900/40 via-gray-800/30 to-gray-900/50" />
      </div>

      {/* Back button */}
      <motion.button
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        onClick={() => navigate("/")}
        className="fixed top-6 left-6 flex items-center gap-2 text-gray-600 hover:text-gray-800 transition-colors bg-white/60 backdrop-blur-sm px-4 py-2 rounded-full border border-white/50 shadow-lg z-50"
      >
        <ArrowLeft className="w-4 h-4" />
        <span className="text-sm">Back</span>
      </motion.button>

      {/* Main content */}
      <div className="relative z-10 min-h-screen flex items-center justify-center p-6 pt-20">
        <div className="w-full max-w-6xl">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: -30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-12"
          >
            <h1 className="text-6xl font-bold mb-2">
              <span className="bg-gradient-to-r from-pink-200 via-purple-200 to-pink-100 bg-clip-text text-transparent drop-shadow-[0_2px_10px_rgba(236,72,153,0.3)]">
                CHANGE TOWARDS MYSELF
              </span>
            </h1>
            <p className="text-white/90 text-lg drop-shadow-lg">
              Express your emotions in your subconscious journal
            </p>
          </motion.div>

          {/* Subconscious Journal */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.8 }}
            className="bg-white/60 backdrop-blur-xl rounded-3xl p-8 border border-white/50 shadow-2xl mb-8"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 bg-gradient-to-br from-pink-400 to-purple-400 rounded-2xl flex items-center justify-center">
                <MessageCircle className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-2xl font-semibold text-gray-800">
                  Subconscious Journal
                </h2>
                <p className="text-sm text-gray-500">
                  Write freely about your emotions
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {emotions.map((emotion, index) => (
                <motion.div
                  key={emotion.name}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.3 + index * 0.05 }}
                  className="group"
                >
                  <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-4 border border-gray-100 hover:shadow-lg transition-all">
                    <div className="flex items-center gap-2 mb-3">
                      <div
                        className={`w-8 h-8 bg-gradient-to-br ${emotion.color} rounded-lg`}
                      />
                      <label className="text-sm font-medium text-gray-700 flex items-center gap-1">
                        <span className="text-base">
                          {emotion.emoji}
                        </span>
                        {emotion.name}
                      </label>
                    </div>
                    <textarea
                      value={entries[emotion.name] || ""}
                      onChange={(e) =>
                        handleEntryChange(
                          emotion.name,
                          e.target.value,
                        )
                      }
                      placeholder={`Express your ${emotion.name.toLowerCase()}...`}
                      className="w-full bg-gray-50/50 rounded-xl px-4 py-2 text-sm text-gray-700 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-purple-200 transition-all resize-none h-20"
                    />
                  </div>
                </motion.div>
              ))}
            </div>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="mt-6 w-full py-4 bg-gradient-to-r from-pink-400 to-purple-400 text-white rounded-2xl font-medium shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2"
              onClick={handleDumpThoughts}
            >
              <Trash2 className="w-5 h-5" />
              DUMP MY THOUGHTS
            </motion.button>

            {/* Success Message */}
            <AnimatePresence>
              {showSuccessMessage && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.5 }}
                  className="mt-6 bg-gradient-to-r from-green-400 to-emerald-400 text-white px-8 py-6 rounded-2xl shadow-xl text-center"
                >
                  <p className="text-xl font-semibold mb-2">
                    🌟 Thank You for Freeing Your Mind! 🌟
                  </p>
                  <p className="text-sm opacity-90">
                    MAKE YOUR MIND AND SOUL FREE BY LISTENING TO
                    THEM...
                  </p>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </div>
      </div>
    </div>
  );
}