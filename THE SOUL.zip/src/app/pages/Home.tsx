import {
  Brain,
  Lightbulb,
  Sparkles,
  ArrowRight,
} from "lucide-react";
import { useNavigate } from "react-router";
import { motion } from "motion/react";
import cherryBlossomBg from "figma:asset/07c9185520b8f99e9008d13a8dd249aa6b8cd689.png";
import { Twitter, Facebook, Linkedin } from "lucide-react";

export default function Home() {
  const navigate = useNavigate();

  const cardVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: (i: number) => ({
      opacity: 1,
      y: 0,
      transition: {
        delay: i * 0.15,
        duration: 0.7,
        ease: [0.22, 1, 0.36, 1],
      },
    }),
  };

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Cherry Blossom Background */}
      <div className="absolute inset-0 z-0">
        <img
          src={cherryBlossomBg}
          alt="Cherry blossom background"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-sky-100/40 via-transparent to-orange-100/30" />
      </div>

      {/* Main content */}
      <div className="relative z-10 min-h-screen flex items-center justify-center p-6">
        <div className="w-full max-w-7xl">
          {/* Main heading with animation */}
          <motion.div
            initial={{ opacity: 0, y: -30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="text-center mb-40"
          >
            <h1 className="text-7xl font-bold mb-8 bg-gradient-to-r from-blue-500 via-blue-1000 to-orange-250 bg-clip-text text-transparent">
              SOUL
            </h1>

            {/* Decorative 3D sphere */}
            <motion.div
              className="w-32 h-32 mx-auto mb-8 relative"
              animate={{
                y: [0, -15, 0],
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-blue-200 via-blue-100 to-blue-300 rounded-full blur-2xl opacity-80" />
              <div
                className="absolute inset-2 bg-gradient-to-br from-blue-500 via-blue-500 to-blue-500 rounded-full"
                style={{
                  boxShadow:
                    "0 20px 60px rgba(121, 109, 191, 0.3), inset 0 -10px 40px rgba(255, 255, 255, 0.5)",
                }}
              />
            </motion.div>

            <motion.p
              className="text-gray-5000 text-lg max-w-3xl mx-auto"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5, duration: 1 }}
            ></motion.p>
          </motion.div>
          {/* Cards container */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {/* Psychological Card */}
            <motion.div
              custom={0}
              initial="hidden"
              animate="visible"
              variants={cardVariants}
              whileHover={{
                y: -8,
                transition: { duration: 0.2 },
              }}
              onClick={() => navigate("/psychological")}
              className="group bg-white/10 backdrop-blur-xl rounded-3xl p-8 cursor-pointer border border-white/50 shadow-xl hover:shadow-2xl transition-all relative overflow-hidden"
            >
              {/* Gradient overlay on hover */}
              <div className="absolute inset-0 bg-gradient-to-br from-blue-100/50 to-blue-100/50 opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-3xl" />

              <div className="relative z-10">
                <motion.div
                  className="w-14 h-14 mb-6 bg-gradient-to-br from-blue-500 via-blue-500 to-blue-500 rounded-2xl flex items-center justify-center shadow-lg"
                  animate={{
                    boxShadow: [
                      "0 4px 20px rgba(0, 255, 231, 0.4)",
                      "0 4px 30px rgba(208, 242, 242, 0.6)",
                      "0 4px 20px rgba(0, 255, 231, 0.4)",
                    ],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }}
                >
                  <Brain
                    className="w-7 h-7 text-white"
                    strokeWidth={2}
                  />
                </motion.div>

                <h2 className="text-2xl font-semibold text-gray-800 mb-3">
                  Psychological
                </h2>
                <p className="text-gray-600 text-sm leading-relaxed mb-6">
                  Explore patterns, behaviors, and deep-rooted
                  insights to understand yourself.
                </p>

                <div className="flex items-center text-blue-500 text-sm font-medium group-hover:gap-2 transition-all">
                  <span>Explore</span>
                  <ArrowRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-all" />
                </div>
              </div>
            </motion.div>

            {/* Mental Card */}
            <motion.div
              custom={1}
              initial="hidden"
              animate="visible"
              variants={cardVariants}
              whileHover={{
                y: -8,
                transition: { duration: 0.2 },
              }}
              onClick={() => navigate("/mental")}
              className="group bg-white/10 backdrop-blur-xl rounded-3xl p-8 cursor-pointer border border-white/50 shadow-xl hover:shadow-2xl transition-all relative overflow-hidden"
            >
              {/* Gradient overlay on hover */}
              <div className="absolute inset-0 bg-gradient-to-br from-blue-100/50 to-blue-100/50 opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-3xl" />

              <div className="relative z-10">
                <motion.div
                  className="w-14 h-14 mb-6 bg-gradient-to-br from-blue-500 via-blue-500 to-blue-500 rounded-2xl flex items-center justify-center shadow-lg"
                  animate={{
                    boxShadow: [
                      "0 4px 20px rgba(0, 255, 231, 0.4)",
                      "0 4px 30px rgba(208, 242, 242, 0.6)",
                      "0 4px 20px rgba(0, 255, 231, 0.4)",
                    ],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }}
                >
                  <Lightbulb
                    className="w-7 h-7 text-white"
                    strokeWidth={2}
                  />
                </motion.div>

                <h2 className="text-2xl font-semibold text-gray-800 mb-3">
                  Mental
                </h2>
                <p className="text-gray-600 text-sm leading-relaxed mb-6">
                  Optimize focus, clarity, and cognitive
                  performance for a balanced life.
                </p>

                <div className="flex items-center text-blue-500 text-sm font-medium group-hover:gap-2 transition-all">
                  <span>Explore</span>
                  <ArrowRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-all" />
                </div>
              </div>
            </motion.div>

            {/* Spiritual Card */}
            <motion.div
              custom={2}
              initial="hidden"
              animate="visible"
              variants={cardVariants}
              whileHover={{
                y: -8,
                transition: { duration: 0.2 },
              }}
              onClick={() => navigate("/spiritual")}
              className="group bg-white/10 backdrop-blur-xl rounded-3xl p-8 cursor-pointer border border-white/50 shadow-xl hover:shadow-2xl transition-all relative overflow-hidden"
            >
              {/* Gradient overlay on hover */}
              <div className="absolute inset-0 bg-gradient-to-br from-blue-100/50 to-blue-100/50 opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-3xl" />

              <div className="relative z-10">
                <motion.div
                  className="w-14 h-14 mb-6 bg-gradient-to-br from-blue-500 via-blue-500 to-blue-500 rounded-2xl flex items-center justify-center shadow-lg"
                  animate={{
                    boxShadow: [
                      "0 4px 20px rgba(0, 255, 231, 0.4)",
                      "0 4px 30px rgba(208, 242, 242, 0.6)",
                      "0 4px 20px rgba(0, 255, 231, 0.4)",
                    ],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }}
                >
                  <Sparkles
                    className="w-7 h-7 text-white"
                    strokeWidth={2}
                  />
                </motion.div>

                <h2 className="text-2xl font-semibold text-gray-800 mb-3">
                  Spiritual
                </h2>
                <p className="text-gray-600 text-sm leading-relaxed mb-6">
                  Connect with purpose, meaning, and inner
                  stillness to find peace.
                </p>

                <div className="flex items-center text-blue-500 text-sm font-medium group-hover:gap-2 transition-all">
                  <span>Explore</span>
                  <ArrowRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-all" />
                </div>
              </div>
            </motion.div>
          </div>

          {/* Footer Section */}
          <motion.footer
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.2, duration: 1 }}
            className="bg-white/50 backdrop-blur-lg rounded-3xl p-8 mt-12 border border-white/50"
          >
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              {/* Credit Section */}
              <div>
                <h3 className="text-sm font-semibold text-gray-500 uppercase mb-3">
                  Credit
                </h3>
                <h2 className="text-2xl font-bold text-gray-900 mb-2">
                  Soul Wellness
                </h2>
                <p className="text-sm text-gray-600">© 2026</p>
              </div>

              {/* Contact Section */}
              <div>
                <h3 className="text-sm font-semibold text-gray-500 uppercase mb-3">
                  Contact
                </h3>
                <ul className="space-y-2">
                  <li>
                    <a
                      href="mailto:hello@soulwellness.com"
                      className="text-sm text-gray-700 hover:text-gray-900 transition-colors"
                    >
                      Email
                    </a>
                  </li>
                </ul>
              </div>

              {/* Socialize Section */}
              <div>
                <h3 className="text-sm font-semibold text-gray-500 uppercase mb-3">
                  Socialize
                </h3>
                <ul className="space-y-2">
                  <li>
                    <a
                      href="#"
                      className="text-sm text-gray-700 hover:text-gray-900 transition-colors flex items-center gap-2"
                    >
                      <Facebook className="w-4 h-4" />
                      Facebook
                    </a>
                  </li>
                  <li>
                    <a
                      href="#"
                      className="text-sm text-gray-700 hover:text-gray-900 transition-colors flex items-center gap-2"
                    >
                      <Twitter className="w-4 h-4" />
                      Twitter
                    </a>
                  </li>
                  <li>
                    <a
                      href="#"
                      className="text-sm text-gray-700 hover:text-gray-900 transition-colors flex items-center gap-2"
                    >
                      <Linkedin className="w-4 h-4" />
                      LinkedIn
                    </a>
                  </li>
                </ul>
              </div>

              {/* Resources Section */}
              <div>
                <h3 className="text-sm font-semibold text-gray-500 uppercase mb-3">
                  Resources
                </h3>
                <ul className="space-y-2">
                  <li>
                    <a
                      href="#"
                      className="text-sm text-gray-700 hover:text-gray-900 transition-colors"
                    >
                      Wellness Blog
                    </a>
                  </li>
                  <li>
                    <a
                      href="#"
                      className="text-sm text-gray-700 hover:text-gray-900 transition-colors"
                    >
                      Meditation Guide
                    </a>
                  </li>
                  <li>
                    <a
                      href="#"
                      className="text-sm text-gray-700 hover:text-gray-900 transition-colors"
                    >
                      Mental Health
                    </a>
                  </li>
                </ul>
              </div>
            </div>

            {/* About Section */}
            <div className="mt-8 pt-8 border-t border-gray-200">
              <h3 className="text-sm font-semibold text-gray-500 uppercase mb-3">
                About
              </h3>
              <p className="text-sm text-gray-700 leading-relaxed max-w-3xl">
                We built Soul Wellness because we believe tools
                for mental, psychological, and spiritual growth
                should be well designed and accessible. If you
                like the platform or have a suggestion, drop us
                a line; feedback is very much appreciated and
                always welcome!
              </p>
            </div>

            {/* Quote Section */}
            <div className="mt-8 pt-8 border-t border-gray-200 text-center">
              <p className="text-gray-800 font-bold text-xl uppercase tracking-wide">
                YOUR PERSONAL JOURNEY TO MENTAL, PSYCHOLOGICAL,
                AND SPIRITUAL WELLNESS
              </p>
            </div>
          </motion.footer>
        </div>
      </div>
    </div>
  );
}