import { useState } from 'react';
import { X, Send } from 'lucide-react';
import { useNavigate } from 'react-router';

const journalPrompts = [
  { label: 'Anger', placeholder: 'What makes me angry right now...' },
  { label: 'Fear', placeholder: 'What am I afraid of...' },
  { label: 'Greed', placeholder: 'What do I desire excessively...' },
  { label: 'Sadness', placeholder: 'What saddens my heart...' },
  { label: 'Anxiety', placeholder: 'What worries occupy my mind...' },
  { label: 'Guilt', placeholder: 'What do I feel guilty about...' },
  { label: 'Jealousy', placeholder: 'What triggers my jealousy...' },
  { label: 'Shame', placeholder: 'What do I feel ashamed of...' },
  { label: 'Resentment', placeholder: 'Who or what do I resent...' },
  { label: 'Confusion', placeholder: 'What confuses me...' },
];

export default function SubconsciousJournal() {
  const navigate = useNavigate();
  const [entries, setEntries] = useState<string[]>(Array(journalPrompts.length).fill(''));

  const handleEntryChange = (index: number, value: string) => {
    const newEntries = [...entries];
    newEntries[index] = value;
    setEntries(newEntries);
  };

  const totalWords = entries.join(' ').trim().split(/\s+/).filter(word => word.length > 0).length;

  const handleDumpThoughts = () => {
    // Here you could save the thoughts to localStorage or a database
    console.log('Thoughts dumped:', entries);
    // Clear the content
    setEntries(Array(journalPrompts.length).fill(''));
    // Optionally show a success message
    alert('Your thoughts have been safely stored.');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-yellow-50 to-amber-50 flex items-center justify-center p-6">
      <div className="w-full max-w-5xl bg-gradient-to-br from-amber-50 to-yellow-100 rounded-3xl shadow-2xl p-12 relative">
        {/* Close button */}
        <button
          onClick={() => navigate('/psychological')}
          className="absolute top-8 right-8 text-amber-800 hover:text-amber-900 transition-colors"
        >
          <X className="w-6 h-6" />
        </button>

        {/* Header */}
        <div className="mb-8">
          <h1 className="text-5xl text-amber-900 mb-2" style={{ fontFamily: 'Georgia, serif' }}>
            Subconscious Journal
          </h1>
          <p className="text-amber-600 text-sm">
            A safe space to release your deepest emotions—write what weighs on your heart
          </p>
        </div>

        {/* Writing area - themed prompts with minimal lines */}
        <div className="space-y-3 mb-8">
          {journalPrompts.map((prompt, index) => (
            <div key={index} className="flex items-start gap-4">
              <label className="w-28 text-amber-700 text-sm pt-2 flex-shrink-0" style={{ fontFamily: 'Georgia, serif' }}>
                {prompt.label}:
              </label>
              <input
                type="text"
                value={entries[index]}
                onChange={(e) => handleEntryChange(index, e.target.value)}
                placeholder={prompt.placeholder}
                className="flex-1 bg-transparent border-b border-amber-300 text-amber-800 placeholder-amber-400/60 focus:outline-none focus:border-amber-500 text-sm py-2 leading-relaxed"
                style={{ fontFamily: 'Georgia, serif' }}
              />
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between">
          <p className="text-amber-400 italic text-sm" style={{ fontFamily: 'Georgia, serif' }}>
            "Writing is the antidote to confusion and chaos"
          </p>
          
          <div className="flex items-center gap-4">
            <span className="text-amber-400 text-sm">{totalWords} words</span>
            <button
              onClick={handleDumpThoughts}
              className="flex items-center gap-2 bg-gradient-to-r from-amber-400 to-yellow-500 text-white px-6 py-3 rounded-full hover:from-amber-500 hover:to-yellow-600 transition-all shadow-md"
            >
              <Send className="w-4 h-4" />
              <span>Dump My Thoughts</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}