import { createBrowserRouter } from "react-router";
import Home from "./pages/Home";
import PsychologicalPage from "./pages/PsychologicalPage";
import MentalPage from "./pages/MentalPage";
import SubconsciousJournal from "./pages/SubconsciousJournal";
import SpiritualPage from "./pages/SpiritualPage";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Home,
  },
  {
    path: "/psychological",
    Component: PsychologicalPage,
  },
  {
    path: "/mental",
    Component: MentalPage,
  },
  {
    path: "/journal",
    Component: SubconsciousJournal,
  },
  {
    path: "/spiritual",
    Component: SpiritualPage,
  },
  {
    path: "*",
    Component: Home,
  },
]);